tinymce.addI18n('fr_FR', {
    'Bullet List' : "Bullet List",
    'Circle List' : "Circle List",
    'Square List' : "Square List",
    'Arrow List' : "Arrow List",
    'Label List' : "Label List",
});


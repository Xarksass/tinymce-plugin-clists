tinymce.addI18n('fr_FR', {
    'Bullet List' : "Puces rondes",
    'Circle List' : "Puces cercles",
    'Square List' : "Puces carrées",
    'Arrow List' : "Puces flèches",
    'Label List' : "Puces étiquettes",
});
